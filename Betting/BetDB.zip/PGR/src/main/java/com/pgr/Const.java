package com.pgr;

// API주소
public class Const {
	public static final String RECENT_MATCHES = "http://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard?limit=5";
	public static final String TEAMS_STAT = "http://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/teams";
}
