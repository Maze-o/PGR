package com.pgr.chating;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class pgrApplication {

	public static void main(String[] args) {
		SpringApplication.run(pgrApplication.class, args);
	}

}
