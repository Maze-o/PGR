package com.pgr.model;

public class BetDTO extends BetEntity{

}
