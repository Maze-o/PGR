package com.pgr.model;

public class BetEntity {
	private int userPk;
	private int property;
	private int id;
	private int team;
	private int win;
	private int lose;
	private int draw;
	private int myProperty;
	private int bResult;
	private int success;
	private int cTeam;
	
	public int getMyProperty() {
		return myProperty;
	}
	public void setMyProperty(int myProperty) {
		this.myProperty = myProperty;
	}
	public int getbResult() {
		return bResult;
	}
	public void setbResult(int bResult) {
		this.bResult = bResult;
	}

	public int getSuccess() {
		return success;
	}
	public void setSuccess(int success) {
		this.success = success;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	public int getLose() {
		return lose;
	}
	public void setLose(int lose) {
		this.lose = lose;
	}
	public int getDraw() {
		return draw;
	}
	public void setDraw(int draw) {
		this.draw = draw;
	}
	public int getUserPk() {
		return userPk;
	}
	public void setUserPk(int userPk) {
		this.userPk = userPk;
	}
	public int getProperty() {
		return property;
	}
	public void setProperty(int property) {
		this.property = property;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getTeam() {
		return team;
	}
	public void setTeam(int team) {
		this.team = team;
	}
	public int getcTeam() {
		return cTeam;
	}
	public void setcTeam(int cTeam) {
		this.cTeam = cTeam;
	}
	
}
