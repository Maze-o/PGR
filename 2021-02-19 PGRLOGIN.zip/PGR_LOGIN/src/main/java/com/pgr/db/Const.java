package com.pgr.db;

// API주소
public class Const {
	public static final String RECENT_MATCHES = "http://site.api.espn.com/apis/site/v2/sports/soccer/eng.1/scoreboard?limit=5";
}
